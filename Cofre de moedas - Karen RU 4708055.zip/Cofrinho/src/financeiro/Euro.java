package financeiro;

public class Euro extends Moeda {
	
    public Euro(double valor, String tipo) {
        super(valor, tipo);
    }

    @Override
    double converter() {
        // Conversão de euro para real (1 euro = 6,21 reais) em 27/03/2025
        return getValor() * 6.21;
    }

	@Override
	public String toString() {
		return "Euro [converter()=" + converter() + ", Valor()=" + getValor() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

	@Override
	public int hashCode() {
		return super.hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
    
    
}

